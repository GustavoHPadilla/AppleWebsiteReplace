const btt_mobile = document.getElementById("btt_mobile")
const ul = document.querySelector('header > ul')

function toggle_menu(event){

    if(event.type == 'touchstart') event.preventDefault()

    btt_mobile.classList.toggle('active')
    ul.classList.toggle('active')

}

btt_mobile.addEventListener('click', toggle_menu)
btt_mobile.addEventListener('touchstart', toggle_menu)